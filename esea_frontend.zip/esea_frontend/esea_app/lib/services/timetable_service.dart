import 'dio_client.dart';
import '../constants/api_constants.dart';

class TimetableService {
  final DioClient _dio = DioClient();

  Future<List<dynamic>> fetchSlotTimeMap() async {
    final res = await _dio.get(ApiConstants.slotTimeMap);
    return res.data;
  }

  Future<List<dynamic>> fetchDepartmentTimetable() async {
    final res = await _dio.get(ApiConstants.departmentTimetable);
    return res.data;
  }

  Future<List<dynamic>> fetchStudentTimetable() async {
    final res = await _dio.get(ApiConstants.studentTimetable);
    return res.data;
  }

  Future<List<dynamic>> fetchExamTimetable() async {
    final res = await _dio.get(ApiConstants.examTimetable);
    return res.data;
  }

  Future<List<dynamic>> fetchRunningCourses() async {
    final res = await _dio.get(ApiConstants.runningCourses);
    return res.data;
  }
}
