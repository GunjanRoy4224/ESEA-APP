import 'package:dio/dio.dart';
import '../models/course_material_model.dart';
import '../constants/api_constants.dart';
import 'dio_client.dart';

class CourseMaterialService {
  final Dio _dio = DioClient().dio;

  Future<List<CourseMaterial>> fetchAllCourses() async {
    final response = await _dio.get(ApiConstants.courseMaterial);

    return (response.data as List)
        .map((e) => CourseMaterial.fromJson(e))
        .toList();
  }
}
