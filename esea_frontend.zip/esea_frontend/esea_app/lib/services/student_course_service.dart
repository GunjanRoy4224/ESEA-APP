import 'package:dio/dio.dart';
import '../constants/api_constants.dart';
import 'dio_client.dart';

class StudentCourseService {
  final Dio _dio = DioClient().dio;

  Future<List<String>> getSelectedCourses() async {
    final res = await _dio.get(ApiConstants.studentCourses);
    return List<String>.from(res.data);
  }

  Future<void> addCourse(String courseCode) async {
    await _dio.post(
      ApiConstants.studentCourses,
      data: {"course_code": courseCode},
    );
  }

  Future<void> removeCourse(String courseCode) async {
    await _dio.delete(
      ApiConstants.studentCourses,
      data: {"course_code": courseCode},
    );
  }
}
