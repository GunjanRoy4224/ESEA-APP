class TimetableEntry {
  final String day;
  final String slot;
  final String courseCode;
  final String title;

  TimetableEntry({
    required this.day,
    required this.slot,
    required this.courseCode,
    required this.title,
  });

  factory TimetableEntry.fromJson(Map<String, dynamic> json) {
    return TimetableEntry(
      day: json["day"],
      slot: json["slot"],
      courseCode: json["course_code"],
      title: json["course_title"],
    );
  }
}
