class DepartmentCourse {
  final String courseCode;
  final String slot;
  final int credit;
  final String courseTitle;
  final String instructor;
  final String? classroom;
  final String tag;
  final String program;

  DepartmentCourse({
    required this.courseCode,
    required this.slot,
    required this.credit,
    required this.courseTitle,
    required this.instructor,
    this.classroom,
    required this.tag,
    required this.program,
  });

  factory DepartmentCourse.fromJson(Map<String, dynamic> json) {
    return DepartmentCourse(
      courseCode: json["course_code"],
      slot: json["slot"],
      credit: json["credit"],
      courseTitle: json["course_title"],
      instructor: json["instructor"],
      classroom: json["classroom"],
      tag: json["tag"],
      program: json["program"],
    );
  }
}

