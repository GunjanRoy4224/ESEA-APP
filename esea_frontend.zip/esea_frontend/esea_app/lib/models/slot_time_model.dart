// class SlotTime {
//   final String slot;
//   final String day;
//   final String startTime;
//   final String endTime;

//   SlotTime({
//     required this.slot,
//     required this.day,
//     required this.startTime,
//     required this.endTime,
//   });

//   factory SlotTime.fromJson(Map<String, dynamic> json) {
//     return SlotTime(
//       slot: json['slot'],
//       day: json['day'],
//       startTime: json['start_time'],
//       endTime: json['end_time'],
//     );
//   }
// }
class SlotTime {
  final String slot;
  final String day;
  final String time; // e.g. "09:00 - 10:00"

  SlotTime({
    required this.slot,
    required this.day,
    required this.time,
  });

  factory SlotTime.fromJson(Map<String, dynamic> json) {
    return SlotTime(
      slot: json['slot'],
      day: json['day'],
      time: json['time'],
    );
  }
}
