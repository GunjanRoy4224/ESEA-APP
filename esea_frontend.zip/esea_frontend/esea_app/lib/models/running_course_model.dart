class RunningCourse {
  final String courseCode;
  final String slot;
  final String credits;
  final String title;
  final String instructor;
  final String classroom;
  final String tag;
  final String program;

  RunningCourse({
    required this.courseCode,
    required this.slot,
    required this.credits,
    required this.title,
    required this.instructor,
    required this.classroom,
    required this.tag,
    required this.program,
  });

  factory RunningCourse.fromJson(Map<String, dynamic> json) {
    return RunningCourse(
      courseCode: json['course_code'],
      slot: json['slot'],
      credits: json['credits'],
      title: json['title'],
      instructor: json['instructor'],
      classroom: json['classroom'] ?? "",
      tag: json['tag'],
      program: json['program'],
    );
  }
}
