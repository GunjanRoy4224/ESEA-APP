import 'dart:convert';

class User {
  final String id;
  final String name;
  final String rollNumber;
  final String eseaId;
  final String department;
  final String year;
  final String email;
  final String? photoUrl;

  User({
    required this.id,
    required this.name,
    required this.rollNumber,
    required this.eseaId,
    required this.department,
    required this.year,
    required this.email,
    this.photoUrl,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'].toString(),
      name: json['name'] ?? '',
      rollNumber: json['roll_number'] ?? '',
      eseaId: json['esea_id'] ?? '',
      department: json['department'] ?? '',
      year: json['year'] ?? '',
      email: json['email'] ?? '',
      photoUrl: json['photo_url'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'roll_number': rollNumber,
      'esea_id': eseaId,
      'department': department,
      'year': year,
      'email': email,
      'photo_url': photoUrl,
    };
  }

  String toJsonString() => jsonEncode(toJson());

  factory User.fromJsonString(String str) =>
      User.fromJson(jsonDecode(str));
}
