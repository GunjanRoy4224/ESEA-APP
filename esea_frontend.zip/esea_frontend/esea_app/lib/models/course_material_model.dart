class CourseMaterial {
  final int id;
  final String title;
  final String? description;
  final String materialType;
  final String courseName;
  final String? instructor;
  final String fileUrl;
  final int? fileSize;
  final String? fileExtension;
  final int downloadCount;
  final DateTime uploadedAt;

  CourseMaterial({
    required this.id,
    required this.title,
    this.description,
    required this.materialType,
    required this.courseName,
    this.instructor,
    required this.fileUrl,
    this.fileSize,
    this.fileExtension,
    required this.downloadCount,
    required this.uploadedAt,
  });

  factory CourseMaterial.fromJson(Map<String, dynamic> json) {
    return CourseMaterial(
      id: json['id'] as int,
      title: json['title'] as String,
      description: json['description'] as String?,
      materialType: json['material_type'] as String,
      courseName: json['course_name'] as String,
      instructor: json['instructor'] as String?,
      fileUrl: json['file_url'] as String,
      fileSize: json['file_size'] as int?,
      fileExtension: json['file_extension'] as String?,
      downloadCount: json['download_count'] as int,
      uploadedAt: DateTime.parse(json['uploaded_at'] as String),
    );
  }

  String get fileSizeFormatted {
    if (fileSize == null) return 'Unknown';
    
    if (fileSize! < 1024) {
      return '$fileSize B';
    } else if (fileSize! < 1024 * 1024) {
      return '${(fileSize! / 1024).toStringAsFixed(1)} KB';
    } else {
      return '${(fileSize! / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
  }
}