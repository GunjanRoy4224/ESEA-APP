import 'package:flutter/material.dart';
import '../../utils/timetable_mapper.dart';
import '../../widgets/weekly_timetable_grid.dart';
import '../../models/slot_time_model.dart';
import '../../models/department_course_model.dart';

class DepartmentTimetableWidget extends StatelessWidget {
  const DepartmentTimetableWidget({super.key});

  @override
  Widget build(BuildContext context) {
    // TEMP: Replace with real API data
    final List<SlotTime> slots = [];
    final List<DepartmentCourse> courses = [];

    final timetable =
        buildWeeklyTimetable(slots: slots, courses: courses);

    if (timetable.isEmpty) {
      return const Center(child: Text("Timetable not available"));
    }

    return WeeklyTimetableGrid(timetable: timetable);
  }
}
