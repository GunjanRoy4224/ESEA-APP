import 'package:flutter/material.dart';
import '../../models/department_course_model.dart';
import '../../models/slot_time_model.dart';
import '../../services/student_course_service.dart';
import '../../utils/timetable_mapper.dart';
import '../../widgets/weekly_timetable_grid.dart';
import '../../widgets/course_selector_sheet.dart';

class StudentTimetableWidget extends StatefulWidget {
  const StudentTimetableWidget({super.key});

  @override
  State<StudentTimetableWidget> createState() =>
      _StudentTimetableWidgetState();
}

class _StudentTimetableWidgetState extends State<StudentTimetableWidget> {
  final StudentCourseService _courseService = StudentCourseService();

  List<String> selectedCodes = [];

  @override
  void initState() {
    super.initState();
    _loadSelected();
  }

  Future<void> _loadSelected() async {
    selectedCodes = await _courseService.getSelectedCourses();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // Replace with real API data
    final List<DepartmentCourse> allCourses = [];
    final List<SlotTime> slots = [];

    final selectedCourses = allCourses
        .where((c) => selectedCodes.contains(c.courseCode))
        .toList();

    final timetable =
        buildWeeklyTimetable(slots: slots, courses: selectedCourses);

    return Column(
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => const CourseSelectorSheet(),
              );
            },
            child: const Text("Edit Courses"),
          ),
        ),
        timetable.isEmpty
            ? const Text("No courses selected")
            : WeeklyTimetableGrid(timetable: timetable),
      ],
    );
  }
}

class CourseSelectorSheet extends StatelessWidget {
  const CourseSelectorSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Select Course")),
      body: const Center(
        child: Text("Course selector coming soon"),
      ),
    );
  }
}
