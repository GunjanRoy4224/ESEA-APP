import 'package:flutter/material.dart';
import '../../models/running_course_model.dart';
import '../../services/running_courses_service.dart';
import '../../widgets/running_courses_header.dart';

class RunningCoursesScreen extends StatefulWidget {
  const RunningCoursesScreen({super.key});

  @override
  State<RunningCoursesScreen> createState() => _RunningCoursesScreenState();
}

class _RunningCoursesScreenState extends State<RunningCoursesScreen> {
  final RunningCoursesService _service = RunningCoursesService();
  List<RunningCourse> courses = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    courses = await _service.fetchRunningCourses();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(children: const [
              CourseHeader("Course"),
              CourseHeader("Slot"),
              CourseHeader("Cr"),
              CourseHeader("Title"),
              CourseHeader("Instructor"),
              CourseHeader("Room"),
              CourseHeader("Tag"),
            ]),
            const Divider(),

            // Rows
            ...courses.map((c) => Row(
                  children: [
                    _cell(c.courseCode),
                    _cell(c.slot),
                    _cell(c.credits),
                    _cell(c.title),
                    _cell(c.instructor),
                    _cell(c.classroom),
                    _cell(c.tag),
                  ],
                )),

            const SizedBox(height: 20),

            // Program note
            const Text(
              "Program:\n"
              "UG = Undergraduate, PG = Postgraduate, DD = Dual Degree",
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cell(String text) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(text, style: const TextStyle(fontSize: 13)),
      ),
    );
  }
}
