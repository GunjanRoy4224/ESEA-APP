import 'package:flutter/material.dart';

class ExamTimetableWidget extends StatelessWidget {
  const ExamTimetableWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              "Midsem Examination",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text("Exam table grouped by date"),
          ],
        ),
      ),
    );
  }
}
