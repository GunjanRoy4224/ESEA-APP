import 'package:flutter/material.dart';
import '../../models/course_material_model.dart';
import '../../widgets/resource_list_tile.dart';

class CourseMaterialDetailScreen extends StatelessWidget {
  final CourseMaterial course;

  const CourseMaterialDetailScreen({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    final tabs = <Tab>[];
    final views = <Widget>[];

    if (course.lectures.isNotEmpty) {
      tabs.add(const Tab(text: "Lectures"));
      views.add(_buildList(course.lectures));
    }

    if (course.tutorials.isNotEmpty) {
      tabs.add(const Tab(text: "Resources"));
      views.add(_buildList(course.tutorials));
    }

    if (course.pyqs.isNotEmpty) {
      tabs.add(const Tab(text: "PYQs"));
      views.add(_buildList(course.pyqs));
    }

    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text(course.courseCode),
          bottom: TabBar(tabs: tabs),
        ),
        body: TabBarView(children: views),
      ),
    );
  }

  Widget _buildList(List<ResourceItem> items) {
    return ListView(
      children: items
          .map((e) => ResourceListTile(title: e.title, link: e.link))
          .toList(),
    );
  }
}
