import 'package:flutter/material.dart';

class CourseMaterialsScreen extends StatelessWidget {
  const CourseMaterialsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Course Materials")),
      body: const Center(
        child: Text(
          "Course Materials will be listed here",
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
