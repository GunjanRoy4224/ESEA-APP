import 'package:flutter/foundation.dart';
import '../services/api_service.dart';
import '../models/course_material_model.dart';
class MaterialProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  
  List<CourseMaterial> _materials = [];
  bool _isLoading = false;
  String? _error;
  String? _selectedType;

  List<CourseMaterial> get materials => _materials;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String? get selectedType => _selectedType;

  /// Fetch materials
  Future<void> fetchMaterials({String? type, String? search}) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _materials = await _apiService.getMaterials(
        type: type,
        search: search,
      );
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Set type filter
  Future<void> setType(String? type) async {
    _selectedType = type;
    await fetchMaterials(type: type);
  }

  /// Search materials
  Future<void> searchMaterials(String query) async {
    await fetchMaterials(search: query, type: _selectedType);
  }

  /// Download material
  Future<String?> downloadMaterial(int id) async {
    try {
      return await _apiService.downloadMaterial(id);
    } catch (e) {
      return null;
    }
  }
}