import 'dart:async';
import 'package:flutter/material.dart';
import 'package:app_links/app_links.dart';
import '../models/user.dart';
import '../services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  final AppLinks _appLinks = AppLinks();

  User? _user;
  bool _isAuthenticated = false;
  bool _isLoading = false;

  User? get user => _user;
  bool get isAuthenticated => _isAuthenticated;
  bool get isLoading => _isLoading;

  AuthProvider() {
    _init();
  }

  Future<void> _init() async {
    _startDeepLinkListener();
  }

  /// SSO LOGIN
  Future<String?> getSSOLoginUrl() async {
    _isLoading = true;
    notifyListeners();

    try {
      return await _authService.getSSOLoginUrl();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// DEEP LINK HANDLER
  void _startDeepLinkListener() async {
  // 1️⃣ Handle initial link (CRITICAL)
  final Uri? initialUri = await _appLinks.getInitialLink();
  if (initialUri != null) {
    print("Initial deep link: $initialUri");
    await _handleDeepLink(initialUri);
  }

  // 2️⃣ Listen for future links
  _appLinks.uriLinkStream.listen((uri) async {
    if (uri != null) {
      print("Deep link received: $uri");
      await _handleDeepLink(uri);
    }
  });
}

Future<void> _handleDeepLink(Uri uri) async {
  if (uri.scheme == "esea" &&
      uri.host == "auth" &&
      uri.path == "/callback") {

    final token = uri.queryParameters["token"];
    if (token != null) {
      await _handleSuccessfulLogin(token);
    }
  }
}


  Future<void> _handleSuccessfulLogin(String token) async {
    await _authService.saveToken(token);
    _user = await _authService.fetchCurrentUser();
    _isAuthenticated = true;
    notifyListeners();
  }

  Future<void> logout() async {
    await _authService.logout();
    _user = null;
    _isAuthenticated = false;
    notifyListeners();
  }
}
