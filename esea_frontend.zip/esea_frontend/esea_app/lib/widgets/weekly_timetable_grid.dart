import 'package:flutter/material.dart';
import '../models/department_course_model.dart';

class WeeklyTimetableGrid extends StatelessWidget {
  final Map<String, Map<String, List<DepartmentCourse>>> timetable;

  const WeeklyTimetableGrid({super.key, required this.timetable});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: timetable.entries.map((dayEntry) {
        final day = dayEntry.key;
        final slots = dayEntry.value;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            Text(
              day,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            ...slots.entries.map((slotEntry) {
              final time = slotEntry.key;
              final courses = slotEntry.value;

              return Card(
                child: ListTile(
                  title: Text(time),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: courses
                        .map(
                          (c) => Text(
                            "${c.courseCode} — ${c.courseTitle}",
                            style: const TextStyle(fontSize: 13),
                          ),
                        )
                        .toList(),
                  ),
                ),
              );
            }),
          ],
        );
      }).toList(),
    );
  }
}
