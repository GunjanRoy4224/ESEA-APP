import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/content_model.dart';

class ContentCard extends StatelessWidget {
  final ContentModel content;

  const ContentCard({super.key, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12),
      child: InkWell(
        onTap: () async {
          if (content.fileUrl != null) {
            await launchUrl(
              Uri.parse(content.fileUrl!),
              mode: LaunchMode.inAppWebView,
            );
          } else if (content.externalLink != null) {
            await launchUrl(
              Uri.parse(content.externalLink!),
              mode: LaunchMode.externalApplication,
            );
          }
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (content.imageUrl != null)
              Image.network(content.imageUrl!, fit: BoxFit.cover),

            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    content.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(content.shortDescription),
                  if (content.dateOrDeadline != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      content.dateOrDeadline!,
                      style: const TextStyle(
                        color: Colors.redAccent,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
