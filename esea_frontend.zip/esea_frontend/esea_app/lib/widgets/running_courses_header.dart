import 'package:flutter/material.dart';

class CourseHeader extends StatelessWidget {
  final String text;
  const CourseHeader(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 13,
        ),
      ),
    );
  }
}
