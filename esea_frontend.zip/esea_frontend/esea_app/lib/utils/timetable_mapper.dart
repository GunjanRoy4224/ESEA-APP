import '../models/department_course_model.dart';
import '../models/slot_time_model.dart';

Map<String, Map<String, List<DepartmentCourse>>> buildWeeklyTimetable({
  required List<DepartmentCourse> courses,
  required List<SlotTime> slots,
}) {
  final Map<String, Map<String, List<DepartmentCourse>>> table = {};

  for (final slot in slots) {
    table.putIfAbsent(slot.day, () => {});
    table[slot.day]!.putIfAbsent(slot.time, () => []);
  }

  for (final course in courses) {
    final slot = slots.firstWhere(
      (s) => s.slot == course.slot,
      orElse: () => SlotTime(slot: "", day: "", time: ""),
    );

    if (slot.day.isEmpty) continue;

    table[slot.day]![slot.time]!.add(course);
  }

  return table;
}
